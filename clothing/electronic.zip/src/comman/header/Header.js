// import React from 'react'
// import Head from './Head'; 
// import Navbar from './Navbar';
// import Slide from './Slide';
// function Header() {
//   return (
//     <div>
//      <Head/>
//     <Navbar/>
//     <Slide/>
//     </div>
//   )
// }

// export default Header